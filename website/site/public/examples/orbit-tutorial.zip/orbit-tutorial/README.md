# Orbit tutorial / Orbit 教程

This archive preserves an actual Rovai documentation example. Download links are plain text fixtures, not installers.
本包保存本次真实文档演示的项目。下载链接对应普通文本，不是安装包。

- starter/: initial independent project before the implementation request.
- result/: actual implementation, review and contrast repair result.
- mission/DELIVERY.md: actual report from a separate Mission worktree, not a merged change in result/. The report was generated in Chinese and is preserved unchanged.

Open result/index.html to inspect the page. With Node.js installed, run `node verify.mjs` inside result/ for the checks that actually ran. Visual browser interaction, keyboard navigation and download behavior still require your own browser check.
可打开 result/index.html 查看页面。在 result/ 运行 node verify.mjs 可重做本次检查；需要预先安装 Node.js。浏览器交互、键盘操作与实际下载行为仍需单独检查。

Start your own tutorial from starter/, configure a teammate and follow the collaboration guide. Agent results can differ; the measured contrast issue is this recording’s finding, not a promised outcome.
从 starter/ 开始自己的示例，配置队员并按照协作教程操作。智能体的结果可能不同；对比度问题是本次实测发现，并不保证每次复现相同问题。
